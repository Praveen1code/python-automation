# Basic setup
+ Fill out the details in `credentials.py`
+ Each line in ***contacts.txt*** contains a user's name and email 
address separated by a space.
+ ***message.txt*** contains the email body. 

# Instructions for using gmail
+ Use the hostname **'smtp.gmail.com'** and 
port **587**.
+ Log in with the sender gmail account on the web browser.
+ Go to link 
`https://myaccount.google.com/u/1/lesssecureapps?pageId=none`
and set ***Allow less secure apps*** to ***ON***.